export default {
  command: "start",
  description: "memulai bot",
  async run(ctx) {
    await ctx.reply("Bot Telah Di Mulai");
  }
};